// Tambahkan interaktivitas jika diperlukan
console.log("Website portofolio Anda sudah berjalan!");